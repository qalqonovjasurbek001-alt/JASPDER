# JASP Android Project

Bu loyiha mavjud JASP HTML prototipini Android WebView ilovasiga o‘raydi.

## APK yaratish
Android Studio'da papkani oching, Gradle sync qiling va **Build > Build App Bundle(s) / APK(s) > Build APK(s)** ni tanlang.

Package: `com.jasp.game`
Version: `1.0`
Min Android: 6.0 (API 23)
